// Config: how many hours before due date we consider "nearing"
let NEARING_HOURS = 24; // default; user can change via input

const taskInput = document.getElementById("taskInput");
const dueInput = document.getElementById("dueInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");
const requestNotifBtn = document.getElementById("requestNotif");
const nearingHoursInput = document.getElementById("nearingHours");

nearingHoursInput.addEventListener("change", () => {
  const v = parseFloat(nearingHoursInput.value);
  NEARING_HOURS = isFinite(v) && v > 0 ? v : 24;
  saveTasks();
});

// Simple ID generator
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2,8);
}

// Load and save tasks to localStorage
function loadTasks() {
  const raw = localStorage.getItem("todo_tasks_v2");
  if (!raw) return [];
  try { return JSON.parse(raw); } catch { return []; }
}
function saveTasks() {
  localStorage.setItem("todo_tasks_v2", JSON.stringify(tasks));
}

// tasks array in memory
let tasks = loadTasks();
if (!tasks) tasks = [];

// Request notification permission
requestNotifBtn.addEventListener("click", () => {
  if (!("Notification" in window)) {
    alert("This browser does not support notifications.");
    return;
  }
  Notification.requestPermission().then(p => {
    alert("Notification permission: " + p);
  });
});

// Add new task
addBtn.addEventListener("click", addTask);
taskInput.addEventListener("keyup", (e) => { if (e.key === "Enter") addTask(); });

function addTask() {
  const text = taskInput.value.trim();
  const dueVal = dueInput.value; // datetime-local value
  if (!text) return;

  const task = {
    id: uid(),
    text,
    due: dueVal ? new Date(dueVal).toISOString() : null,
    done: false,
    notified: { nearing: false, overdue: false }
  };

  tasks.push(task);
  saveTasks();
  renderTasks();
  taskInput.value = "";
  dueInput.value = "";
}

// Toggle done
function toggleDone(id) {
  const t = tasks.find(x => x.id === id);
  if (!t) return;
  t.done = !t.done;
  // reset notified flags when completed
  if (t.done) t.notified = { nearing: false, overdue: false };
  saveTasks();
  renderTasks();
}

// Remove
function removeTask(id) {
  tasks = tasks.filter(x => x.id !== id);
  saveTasks();
  renderTasks();
}

// Format due display
function formatDue(iso) {
  if (!iso) return "No due date";
  const d = new Date(iso);
  return d.toLocaleString();
}

// Render tasks to DOM
function renderTasks() {
  taskList.innerHTML = "";
  tasks
    .sort((a,b) => {
      if (!a.due) return 1;
      if (!b.due) return -1;
      return new Date(a.due) - new Date(b.due);
    })
    .forEach(t => {
      const li = document.createElement("li");
      li.className = "task-item";
      if (t.done) li.classList.add("completed");

      // Determine state
      const now = Date.now();
      let state = ""; // "", "warning", "urgent", "overdue"
      if (t.due && !t.done) {
        const diffMs = new Date(t.due).getTime() - now;
        const diffH = diffMs / (1000 * 60 * 60);
        if (diffMs < 0) state = "urgent";
        else if (diffH <= NEARING_HOURS) state = "warning";
      }

      if (state === "warning") li.classList.add("warning");
      if (state === "urgent") li.classList.add("urgent");

      li.innerHTML = `
        <div class="task-main">
          <div class="task-title">${escapeHtml(t.text)}</div>
          <div class="task-meta">Due: ${formatDue(t.due)}</div>
        </div>
        <div class="item-actions">
          <button class="small-btn" title="Mark done">${t.done ? "✅" : "☐"}</button>
          <button class="small-btn" title="Delete">❌</button>
        </div>
      `;

      // actions
      li.querySelector(".item-actions .small-btn").addEventListener("click", () => toggleDone(t.id));
      li.querySelectorAll(".small-btn")[1].addEventListener("click", () => removeTask(t.id));

      taskList.appendChild(li);
    });
}

// Escape HTML to avoid injection
function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

// Reminders: check tasks periodically and send notifications / visual flags
function checkReminders() {
  const now = Date.now();
  tasks.forEach(t => {
    if (t.done || !t.due) return;

    const dueMs = new Date(t.due).getTime();
    const diffMs = dueMs - now;
    const diffH = diffMs / (1000 * 60 * 60);

    // Overdue
    if (diffMs <= 0 && !t.notified.overdue) {
      // Visual handled by render (urgent)
      sendNotification(`Task overdue: ${t.text}`, `Was due ${new Date(t.due).toLocaleString()}`);
      t.notified.overdue = true;
      t.notified.nearing = true; // also mark as nearing
      saveTasks();
      renderTasks();
    }
    // Nearing
    else if (diffMs > 0 && diffH <= NEARING_HOURS && !t.notified.nearing) {
      sendNotification(`Task nearing due: ${t.text}`, `Due ${new Date(t.due).toLocaleString()}`);
      t.notified.nearing = true;
      saveTasks();
      renderTasks();
    }
  });
}

// Send browser notification (fallback to alert)
function sendNotification(title, body) {
  try {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(title, { body });
    } else {
      // Fallback: audible and visual
      console.log("Notification:", title, body);
      // Minimal audible beep
      beep();
      // small visible alert
      // Use small non-blocking UI: create a temporary toast
      showToast(title + " — " + body);
    }
  } catch (e) {
    console.error("Notification failed", e);
  }
}

// Small toast implementation
function showToast(text) {
  const toast = document.createElement("div");
  toast.style.position = "fixed";
  toast.style.right = "20px";
  toast.style.bottom = "20px";
  toast.style.background = "rgba(0,0,0,0.85)";
  toast.style.color = "white";
  toast.style.padding = "10px 14px";
  toast.style.borderRadius = "8px";
  toast.style.zIndex = 9999;
  toast.style.boxShadow = "0 6px 20px rgba(0,0,0,0.3)";
  toast.textContent = text;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 6000);
}

// Simple beep using WebAudio
function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "sine";
    o.frequency.value = 880;
    o.connect(g);
    g.connect(ctx.destination);
    g.gain.value = 0.05;
    o.start();
    setTimeout(() => { o.stop(); ctx.close(); }, 180);
  } catch (e) { /* ignore */ }
}

// Start periodic reminder checks
renderTasks();
checkReminders();
setInterval(checkReminders, 60 * 1000); // check every minute

// If running in CodePen preview iframe, notifications may be blocked — log that to console
if (window.location !== window.parent.location) {
  console.log("Note: Browser notifications may be blocked in iframe previews. Open full page to allow notifications.");
}
